﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WingtipSearchAppWeb {
  public class SearchResult {
    public string Title { get; set; }
    public string Path { get; set; }
  }
}